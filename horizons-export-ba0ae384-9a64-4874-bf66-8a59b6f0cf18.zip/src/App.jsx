import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Feather, Sparkles, Quote, Gift, PlayCircle } from 'lucide-react';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';

const RomanticMessagePage = () => {
  const { toast } = useToast();
  const [step, setStep] = useState(0); 
  const [typedMessage, setTypedMessage] = useState("");

  const recipientName = "Meu Amor";
  const senderName = "Seu Admirador Secreto";
  const fullMainMessage = `Se eu pudesse descrever em palavras o que você significa para mim, nem todas as bibliotecas do mundo seriam suficientes. Você é a melodia que embala meus dias, o farol que guia meus passos na escuridão, e a faísca que acende a alegria em minha alma. Cada momento ao seu lado é um presente, uma pintura viva com as cores mais vibrantes do amor. Seu sorriso tem o poder de transformar o ordinário em extraordinário, e seu olhar, ah, seu olhar... é um universo inteiro que eu adoraria explorar infinitamente. Neste Dia dos Namorados, e em todos os outros dias, meu coração transborda de gratidão por ter você. Que nosso caminho continue sendo trilhado com cumplicidade, carinho, e essa magia que só nós entendemos.`;
  
  const paragraphs = fullMainMessage.split('. ');

  const closingMessage = `Com todo o meu amor, sempre e para sempre,`;

  useEffect(() => {
    if (step === 2) {
      let currentParagraphIndex = 0;
      let currentCharIndex = 0;
      let currentTypedParagraph = "";
      setTypedMessage(""); 

      const intervalId = setInterval(() => {
        if (currentParagraphIndex < paragraphs.length) {
          const currentParagraph = paragraphs[currentParagraphIndex] + (currentParagraphIndex < paragraphs.length -1 ? ". " : ".");
          if (currentCharIndex < currentParagraph.length) {
            currentTypedParagraph += currentParagraph[currentCharIndex];
            setTypedMessage(prev => paragraphs.slice(0, currentParagraphIndex).join('. ') + (paragraphs.slice(0, currentParagraphIndex).length > 0 ? ". " : "") + currentTypedParagraph);
            currentCharIndex++;
          } else {
            currentParagraphIndex++;
            currentCharIndex = 0;
            currentTypedParagraph = "";
            if (currentParagraphIndex < paragraphs.length) {
               setTypedMessage(prev => prev + " "); 
            }
          }
        } else {
          clearInterval(intervalId);
          setTimeout(() => setStep(3), 1000); 
        }
      }, 50); 
      return () => clearInterval(intervalId);
    }
  }, [step]);

  const handleStart = () => {
    setStep(1);
  };

  const handleNotImplemented = () => {
    toast({
      title: "🎁 Surpresa em Breve!",
      description: "Este botão guarda um segredo especial que será revelado em breve! Fique de olho! 😉",
      duration: 3000,
    });
  };

  const containerVariants = {
    hidden: { opacity: 0, y: 50, scale: 0.9 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: { duration: 0.8, ease: "easeOut", delay: 0.2 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-700 via-pink-700 to-purple-800 flex flex-col items-center justify-center p-6 text-white overflow-hidden relative selection:bg-pink-400 selection:text-rose-900">
      <motion.div
        className="absolute inset-0 z-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.3 }}
        transition={{ duration: 2 }}
      >
        {[...Array(40)].map((_, i) => (
          <motion.div
            key={`bg-heart-${i}`}
            className="absolute text-rose-300"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              fontSize: `${Math.random() * 2.5 + 0.5}rem`, 
            }}
            initial={{ opacity: 0, scale: 0, rotate: Math.random() * 360 - 180 }}
            animate={{
              opacity: [0, 0.6, 0],
              scale: [0, 1, 0],
              x: `calc(-50% + ${Math.random() * 60 - 30}px)`,
              y: `calc(-50% + ${Math.random() * 60 - 30}px)`,
              rotate: Math.random() * 360,
            }}
            transition={{
              duration: Math.random() * 12 + 6,
              repeat: Infinity,
              delay: Math.random() * 7,
              ease: "linear",
            }}
          >
            <Heart fill="currentColor" />
          </motion.div>
        ))}
      </motion.div>

      <AnimatePresence mode="wait">
        {step === 0 && (
          <motion.div
            key="step0"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8, transition: {duration: 0.4}}}
            className="text-center z-10 flex flex-col items-center"
          >
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
            >
              <Gift size={100} className="text-pink-300 mb-8 drop-shadow-lg" />
            </motion.div>
            <h2 className="text-4xl font-pacifico text-rose-100 mb-6">Uma mensagem especial espera por você...</h2>
            <Button
              onClick={handleStart}
              className="romantic-button py-4 px-8 text-xl group bg-pink-500 hover:bg-pink-600 text-white"
              size="lg"
            >
              Revelar Mensagem <PlayCircle className="ml-2 h-6 w-6 group-hover:animate-pulse" />
            </Button>
          </motion.div>
        )}

        {(step >= 1) && (
          <motion.div
            key="step1plus"
            className="relative z-10 max-w-3xl w-full bg-black/40 backdrop-blur-xl p-8 md:p-12 rounded-3xl shadow-2xl border-2 border-white/25"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            exit={{ opacity: 0, y: -50, transition: {duration: 0.4} }}
          >
            <motion.div
              className="absolute -top-8 -left-8 w-20 h-20 text-pink-400 animate-float"
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
            >
              <Feather className="w-full h-full drop-shadow-[0_0_12px_rgba(236,72,153,0.8)]" />
            </motion.div>
            <motion.div
              className="absolute -bottom-10 -right-10 w-24 h-24 text-purple-400 animate-float"
              style={{ animationDelay: '0.5s' }}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.7, duration: 0.5 }}
            >
              <Sparkles className="w-full h-full drop-shadow-[0_0_12px_rgba(192,132,252,0.8)]" />
            </motion.div>

            <AnimatePresence mode="wait">
              {step >= 1 && (
                <motion.header
                  key="header"
                  className="text-center mb-8"
                  variants={itemVariants}
                  initial="hidden"
                  animate="visible"
                  onAnimationComplete={() => { if(step === 1) setTimeout(() => setStep(2), 500)}}
                >
                  <motion.h1
                    className="font-pacifico text-5xl md:text-6xl text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-rose-300 to-purple-300 mb-3 drop-shadow-lg"
                  >
                    Para Você,{" "}{recipientName}
                  </motion.h1>
                  <motion.div
                    className="w-2/3 h-1 bg-gradient-to-r from-pink-400 to-purple-400 mx-auto rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: "66.66%" }}
                    transition={{ delay: 0.3, duration: 1 }}
                  />
                </motion.header>
              )}
            </AnimatePresence>

            <AnimatePresence mode="wait">
              {step >= 2 && (
                <motion.section
                  key="message"
                  className="my-8 min-h-[200px]"
                  variants={itemVariants}
                  initial="hidden"
                  animate="visible"
                >
                  <Quote className="text-rose-300 w-10 h-10 opacity-60 mb-4" />
                  <div className="text-lg md:text-xl text-rose-100 leading-relaxed tracking-wide font-light">
                    {typedMessage.split('\n').map((paragraph, pIndex) => (
                      <p key={`typed-p-${pIndex}`} className="mb-4">
                        {paragraph}
                        {pIndex === typedMessage.split('\n').length - 1 && step === 2 && (
                           <span className="animate-pulse">|</span>
                        )}
                      </p>
                    ))}
                  </div>
                  {step > 2 && <Quote className="text-rose-300 w-10 h-10 opacity-60 mt-4 ml-auto transform rotate-180" />}
                </motion.section>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {step >= 3 && (
                <motion.footer
                  key="footer"
                  className="text-right mt-10"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1, transition: {delay: 0.5, duration: 1} }}
                  onAnimationComplete={() => setTimeout(() => setStep(4), 500)}
                >
                  <motion.p
                    className="font-pacifico text-2xl md:text-3xl text-pink-300 mb-1"
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.8 }}
                  >
                    {closingMessage}
                  </motion.p>
                  <motion.p
                    className="font-pacifico text-3xl md:text-4xl text-rose-200"
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2, duration: 0.8 }}
                  >
                    {senderName}
                    <Heart className="inline-block ml-2 text-red-500 animate-pulse-glow-heart" size={30} />
                  </motion.p>
                </motion.footer>
              )}
            </AnimatePresence>
            
            <AnimatePresence>
            {step >= 4 && (
              <motion.div 
                key="specialButton"
                className="mt-12 text-center"
                initial={{opacity: 0, y: 20}}
                animate={{opacity: 1, y: 0, transition: {delay: 0.5, duration: 0.7}}}
              >
                <Button
                  onClick={handleNotImplemented}
                  className="romantic-button py-3 px-6 text-lg group bg-purple-500 hover:bg-purple-600 text-white"
                >
                  Um Presente Especial <Gift className="ml-2 h-5 w-5 group-hover:animate-bounce" />
                </Button>
              </motion.div>
            )}
            </AnimatePresence>

          </motion.div>
        )}
      </AnimatePresence>
      <Toaster />
    </div>
  );
};

export default RomanticMessagePage;