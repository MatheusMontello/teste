
export const movieCategories = {
  trending: [
    {
      id: 1,
      title: "The Witcher",
      description: "Geralt de Rívia, um caçador de monstros mutante, luta para encontrar seu lugar num mundo onde as pessoas muitas vezes se mostram mais perversas que as feras.",
      rating: "16+",
      genres: ["Fantasia", "Aventura", "Drama"],
      image: "The Witcher fantasy series with Geralt in medieval armor"
    },
    {
      id: 2,
      title: "Ozark",
      description: "Um consultor financeiro arrasta sua família do subúrbio de Chicago para os Ozarks do Missouri, onde deve lavar US$ 500 milhões em cinco anos para apaziguar um chefe da droga.",
      rating: "18+",
      genres: ["Crime", "Drama", "Thriller"],
      image: "Ozark crime drama series dark atmospheric scene"
    },
    {
      id: 3,
      title: "The Crown",
      description: "Esta série dramática acompanha a vida política e pessoal da Rainha Elizabeth II e os eventos que moldaram a segunda metade do século XX.",
      rating: "14+",
      genres: ["Drama", "História", "Biografia"],
      image: "The Crown royal drama series with Queen Elizabeth"
    },
    {
      id: 4,
      title: "Money Heist",
      description: "Um homem misterioso que atende pelo nome de Professor planeja o maior assalto da história. Para realizar o ambicioso plano, ele recruta uma equipe de oito únicos assaltantes.",
      rating: "16+",
      genres: ["Crime", "Drama", "Thriller"],
      image: "Money Heist Spanish crime series with red masks"
    },
    {
      id: 5,
      title: "Bridgerton",
      description: "Os oito irmãos da família Bridgerton procuram o amor e a felicidade na alta sociedade londrina. Inspirada nos romances best-sellers de Julia Quinn.",
      rating: "14+",
      genres: ["Romance", "Drama", "Período"],
      image: "Bridgerton period romance series elegant ballroom scene"
    }
  ],
  
  series: [
    {
      id: 6,
      title: "Dark",
      description: "Uma criança desaparece na pequena cidade alemã de Winden, revelando os segredos e conexões ocultas entre quatro famílias estranhas.",
      rating: "16+",
      genres: ["Ficção Científica", "Thriller", "Drama"],
      image: "Dark German sci-fi series mysterious forest scene"
    },
    {
      id: 7,
      title: "The Umbrella Academy",
      description: "Uma família disfuncional de super-heróis adotivos se reúne para resolver o mistério da morte de seu pai e a ameaça de um apocalipse iminente.",
      rating: "16+",
      genres: ["Ficção Científica", "Ação", "Comédia"],
      image: "The Umbrella Academy superhero family group shot"
    },
    {
      id: 8,
      title: "Squid Game",
      description: "Centenas de jogadores falidos aceitam um estranho convite para competir em jogos infantis. Dentro os espera um prêmio tentador, com um risco mortal.",
      rating: "18+",
      genres: ["Thriller", "Drama", "Ação"],
      image: "Squid Game Korean survival series with pink guards"
    },
    {
      id: 9,
      title: "Wednesday",
      description: "Inteligente, sarcástica e um pouco morta por dentro, Wednesday Addams investiga uma onda de assassinatos enquanto faz novos amigos na Academia Nevermore.",
      rating: "14+",
      genres: ["Comédia", "Crime", "Fantasia"],
      image: "Wednesday Addams gothic teen series at Nevermore Academy"
    },
    {
      id: 10,
      title: "Elite",
      description: "Quando três adolescentes da classe trabalhadora se matriculam numa escola particular exclusiva na Espanha, o confronto entre eles e os alunos ricos termina em assassinato.",
      rating: "18+",
      genres: ["Drama", "Crime", "Romance"],
      image: "Elite Spanish teen drama series school setting"
    }
  ],
  
  movies: [
    {
      id: 11,
      title: "Red Notice",
      description: "Um agente do FBI se une ao maior ladrão de arte do mundo para capturar a criminosa mais procurada do mundo.",
      rating: "14+",
      genres: ["Ação", "Comédia", "Crime"],
      image: "Red Notice action comedy with Dwayne Johnson and Ryan Reynolds"
    },
    {
      id: 12,
      title: "Don't Look Up",
      description: "Dois astrônomos de baixo nível embarcam numa turnê midiática gigantesca para avisar a humanidade sobre um cometa que se aproxima e vai destruir a Terra.",
      rating: "16+",
      genres: ["Comédia", "Drama", "Ficção Científica"],
      image: "Don't Look Up satirical comedy with Leonardo DiCaprio"
    },
    {
      id: 13,
      title: "The Adam Project",
      description: "Um piloto de caça viaja no tempo e faz uma aliança com sua versão de 12 anos para salvar o futuro.",
      rating: "12+",
      genres: ["Ficção Científica", "Ação", "Aventura"],
      image: "The Adam Project time travel adventure with Ryan Reynolds"
    },
    {
      id: 14,
      title: "Extraction",
      description: "Tyler Rake, um mercenário intrépido do mercado negro, embarca na missão mais mortal de sua carreira quando é recrutado para resgatar o filho sequestrado de um chefe do crime.",
      rating: "18+",
      genres: ["Ação", "Thriller", "Drama"],
      image: "Extraction action thriller with Chris Hemsworth"
    },
    {
      id: 15,
      title: "Bird Box",
      description: "Cinco anos depois que uma presença aterrorizante dizimou a população, uma sobrevivente e seus filhos fazem uma jornada desesperada em busca de segurança.",
      rating: "16+",
      genres: ["Horror", "Thriller", "Drama"],
      image: "Bird Box post-apocalyptic thriller with Sandra Bullock blindfolded"
    }
  ],
  
  action: [
    {
      id: 16,
      title: "6 Underground",
      description: "Seis indivíduos de diferentes partes do mundo, cada um o melhor no que faz, foram escolhidos não apenas por suas habilidades, mas por um desejo único de deletar seus passados para mudar o futuro.",
      rating: "18+",
      genres: ["Ação", "Thriller", "Crime"],
      image: "6 Underground action team with Ryan Reynolds"
    },
    {
      id: 17,
      title: "Triple Frontier",
      description: "Ex-forças especiais aproveitam seus conhecimentos militares para roubar um chefe do narcotráfico sul-americano.",
      rating: "16+",
      genres: ["Ação", "Thriller", "Drama"],
      image: "Triple Frontier military action with Ben Affleck"
    },
    {
      id: 18,
      title: "The Old Guard",
      description: "Um grupo de mercenários imortais com a capacidade misteriosa de se curar tem que lutar para manter sua identidade em segredo quando descobrem uma nova imortal.",
      rating: "16+",
      genres: ["Ação", "Fantasia", "Thriller"],
      image: "The Old Guard immortal warriors with Charlize Theron"
    },
    {
      id: 19,
      title: "Spenser Confidential",
      description: "Spenser, um ex-policial de Boston, faz equipe com Hawk, um aspirante a lutador, para derrubar criminosos em sua cidade natal.",
      rating: "16+",
      genres: ["Ação", "Comédia", "Crime"],
      image: "Spenser Confidential action comedy with Mark Wahlberg"
    },
    {
      id: 20,
      title: "Project Power",
      description: "Em Nova Orleans, uma pílula misteriosa que libera superpoderes únicos por cinco minutos está sendo distribuída nas ruas.",
      rating: "16+",
      genres: ["Ação", "Ficção Científica", "Thriller"],
      image: "Project Power superhero action with Jamie Foxx"
    }
  ]
};
