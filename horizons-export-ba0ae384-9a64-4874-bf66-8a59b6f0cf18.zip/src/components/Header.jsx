
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Bell, User, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleAction = (action) => {
    toast({
      title: "🚧 Este recurso ainda não foi implementado—mas não se preocupe! Você pode solicitá-lo no seu próximo prompt! 🚀",
      duration: 3000,
    });
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      handleAction('search');
    }
  };

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-black/95 backdrop-blur-md' : 'bg-transparent'
      }`}
    >
      <div className="flex items-center justify-between px-6 py-4">
        <div className="flex items-center gap-8">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="text-3xl font-bold netflix-gradient bg-clip-text text-transparent cursor-pointer"
          >
            NETSTREAM
          </motion.div>
          
          <nav className="hidden md:flex items-center gap-6">
            {['Início', 'Séries', 'Filmes', 'Bombando', 'Minha Lista'].map((item) => (
              <Button
                key={item}
                variant="ghost"
                className="text-white hover:text-red-500 transition-colors"
                onClick={() => handleAction('navigate')}
              >
                {item}
              </Button>
            ))}
          </nav>
        </div>
        
        <div className="flex items-center gap-4">
          <form onSubmit={handleSearch} className="hidden md:flex items-center">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Títulos, pessoas, gêneros"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64 bg-black/50 border-gray-600 text-white placeholder:text-gray-400 focus:border-red-500"
              />
            </div>
          </form>
          
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:text-red-500 md:hidden"
            onClick={() => handleAction('search')}
          >
            <Search className="w-5 h-5" />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:text-red-500 relative"
            onClick={() => handleAction('notifications')}
          >
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse-glow"></span>
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:text-red-500"
            onClick={() => handleAction('profile')}
          >
            <User className="w-5 h-5" />
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:text-red-500 md:hidden"
            onClick={() => handleAction('menu')}
          >
            <Menu className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;
