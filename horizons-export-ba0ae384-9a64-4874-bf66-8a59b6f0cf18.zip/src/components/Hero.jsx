
import React from 'react';
import { motion } from 'framer-motion';
import { Play, Info, Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';

const Hero = () => {
  const { toast } = useToast();
  const [isMuted, setIsMuted] = React.useState(true);

  const handleAction = (action) => {
    toast({
      title: "🚧 Este recurso ainda não foi implementado—mas não se preocupe! Você pode solicitá-lo no seu próximo prompt! 🚀",
      duration: 3000,
    });
  };

  const featuredMovie = {
    title: "Stranger Things",
    description: "Quando um garoto desaparece, uma pequena cidade descobre um mistério envolvendo experimentos secretos, forças sobrenaturais aterrorizantes e uma garota muito estranha.",
    rating: "16+",
    year: "2024",
    seasons: "4 temporadas",
    genres: ["Ficção Científica", "Terror", "Drama"]
  };

  return (
    <div className="relative h-screen overflow-hidden">
      <img  
        className="absolute inset-0 w-full h-full object-cover" 
        alt="Stranger Things - Cena dramática com personagens principais"
       src="https://images.unsplash.com/photo-1702258183162-76653a15d2e4" />
      
      <div className="absolute inset-0 hero-gradient" />
      
      <div className="absolute bottom-0 left-0 right-0 p-8 md:p-16">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-2xl"
        >
          <div className="flex items-center gap-4 mb-4">
            <Badge variant="destructive" className="netflix-gradient text-lg px-3 py-1">
              {featuredMovie.rating}
            </Badge>
            <span className="text-white text-lg">{featuredMovie.year}</span>
            <span className="text-white text-lg">{featuredMovie.seasons}</span>
          </div>
          
          <motion.h1
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-5xl md:text-7xl font-bold text-white mb-6 animate-float"
          >
            {featuredMovie.title}
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-xl text-gray-200 mb-6 leading-relaxed"
          >
            {featuredMovie.description}
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="flex items-center gap-3 mb-8"
          >
            {featuredMovie.genres.map((genre, index) => (
              <Badge key={index} variant="secondary" className="text-sm">
                {genre}
              </Badge>
            ))}
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="flex items-center gap-4"
          >
            <Button 
              size="lg" 
              className="netflix-gradient hover:opacity-90 text-lg px-8 py-3 animate-pulse-glow"
              onClick={() => handleAction('play')}
            >
              <Play className="w-6 h-6 mr-2" />
              Assistir
            </Button>
            
            <Button 
              size="lg" 
              variant="secondary" 
              className="bg-gray-600/70 hover:bg-gray-600/90 text-white text-lg px-8 py-3"
              onClick={() => handleAction('info')}
            >
              <Info className="w-6 h-6 mr-2" />
              Mais informações
            </Button>
          </motion.div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="absolute bottom-8 right-8"
        >
          <Button
            variant="secondary"
            size="icon"
            className="bg-gray-600/70 hover:bg-gray-600/90 text-white"
            onClick={() => setIsMuted(!isMuted)}
          >
            {isMuted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
          </Button>
        </motion.div>
      </div>
    </div>
  );
};

export default Hero;
