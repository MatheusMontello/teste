
import React from 'react';
import { motion } from 'framer-motion';
import { Play, Plus, ThumbsUp, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';

const MovieCard = ({ movie, index }) => {
  const { toast } = useToast();

  const handleAction = (action) => {
    toast({
      title: "🚧 Este recurso ainda não foi implementado—mas não se preocupe! Você pode solicitá-lo no seu próximo prompt! 🚀",
      duration: 3000,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="group relative min-w-[280px] cursor-pointer"
    >
      <div className="relative overflow-hidden rounded-lg bg-gradient-to-br from-gray-900 to-black card-hover">
        <img  
          className="w-full h-[400px] object-cover transition-transform duration-300 group-hover:scale-110" 
          alt={`Poster do filme ${movie.title}`}
         src="https://images.unsplash.com/photo-1545168419-7ae9499a3e11" />
        
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        <div className="absolute top-4 left-4">
          <Badge variant="destructive" className="netflix-gradient">
            {movie.rating}
          </Badge>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 p-6 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <h3 className="text-xl font-bold text-white mb-2">{movie.title}</h3>
          <p className="text-gray-300 text-sm mb-4 line-clamp-2">{movie.description}</p>
          
          <div className="flex items-center gap-2 mb-4">
            {movie.genres.map((genre, idx) => (
              <Badge key={idx} variant="secondary" className="text-xs">
                {genre}
              </Badge>
            ))}
          </div>
          
          <div className="flex items-center gap-2">
            <Button 
              size="sm" 
              className="netflix-gradient hover:opacity-90"
              onClick={() => handleAction('play')}
            >
              <Play className="w-4 h-4 mr-1" />
              Assistir
            </Button>
            <Button 
              size="sm" 
              variant="secondary"
              onClick={() => handleAction('add')}
            >
              <Plus className="w-4 h-4" />
            </Button>
            <Button 
              size="sm" 
              variant="secondary"
              onClick={() => handleAction('like')}
            >
              <ThumbsUp className="w-4 h-4" />
            </Button>
            <Button 
              size="sm" 
              variant="secondary"
              onClick={() => handleAction('info')}
            >
              <Info className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default MovieCard;
